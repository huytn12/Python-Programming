#!/bin/bash
# /opt/gradle/gradle-4.6/bin/gradle $GRADLE_BUILD_OPTIONS clean build && java -jar /ngs/app/build/libs/$APP_NAME.war

if [ "$JUNIT_ENV" = "1" ]; then
    /opt/gradle/gradle-4.6/bin/gradle $GRADLE_TEST_OPTIONS clean test

elif [ "$BUILD_ENV" = "1" ]; then
    /opt/gradle/gradle-4.6/bin/gradle $GRADLE_BUILD_OPTIONS clean build

else
    # /opt/gradle/gradle-4.6/bin/gradle -q --build-cache build --continuous &
    # /opt/gradle/gradle-4.6/bin/gradle -q bootRun
    # /opt/gradle/gradle-4.6/bin/gradle --build-cache assemble
    /opt/gradle/gradle-4.6/bin/gradle $GRADLE_BUILD_OPTIONS build &
    /opt/gradle/gradle-4.6/bin/gradle $GRADLE_BOOTRUN_OPTIONS bootRun
fi
