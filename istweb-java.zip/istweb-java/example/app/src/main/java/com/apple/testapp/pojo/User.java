/**
 * User pojo for getting user related details
 * as part of response body.
 */
package com.apple.testapp.pojo;

public class User {
    /**
     * Store user id
     * @access private
     * @var Integer id
     */
    private Integer id; 
    /**
     * Store user name
     * @access private
     * @var String username
     */  
    private String name;
    /**
     * Set user id
     * @access public
     * @param Integer id
     * @return void
     */
    public void setId(Integer id) {
        this.id = id;
    }
    /**
     * Set user id
     * @access public
     * @param String id
     * @return void
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * Get user id
     * @access public
     * @param void
     * @return Integer id
     */
    public Integer getId() {
        return id;
    }
    /**
     * Get username, which is a unique value
     * @access public
     * @param void
     * @return String userName
     */
    public String getName() {
        return name;
    }

}



