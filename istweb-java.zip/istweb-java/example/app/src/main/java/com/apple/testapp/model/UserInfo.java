/**
 * User pojo for getting user related details
 * as part of response body.
 */
package com.apple.testapp.model;

import com.apple.testapp.pojo.User;

// @JsonInclude(Include.NON_NULL)
public class UserInfo {

    public User userDetails;

}