package com.apple.testapp.dao;

import org.springframework.stereotype.Repository;
import com.apple.testapp.pojo.User;

@Repository
public class UserDao {

    /**
     * @todo: Need to extend this methog to use DB connection
     * 
     * Find user by name
     * @access public
     * @param String name
     * @return User user
     */
    public User findUserByName(String name) {
        //
		return this.mokeDBloader(name);
	}

    /**
     * Private funtion to load data for moke purpose
     * @access private
     * @param String name
     * @return User user
     */
    private User mokeDBloader(String name){
        User user = new User();
        user.setName(name);
        if (name.equals("John")){
            user.setId(1234);
        }else if (name.equals("Rob")){
            user.setId(1111);
        }else{
            user.setName("default");
            user.setId(0000);
        }
        return user;
    }

}