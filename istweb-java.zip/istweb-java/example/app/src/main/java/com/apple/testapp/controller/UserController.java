package com.apple.testapp.contorller;


import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.apple.testapp.service.UserService;
import com.apple.testapp.model.ApiResponse;
import com.apple.testapp.model.UserInfo;

/**
 * User contoller for mapping /user end point action
 * @access public
 */
@RestController
@RequestMapping("user")
public class UserController {

	@Autowired
    private UserService	userService;
    
    //logger
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    /**
     * Default action for this controller
     * @access public
     */
    @GetMapping("/")
    public String index() {
        //Logging sample
        log.error("Error logs");
        return "Initial load action";
    }

    @GetMapping("/info")
    public UserResponse getInfo(@RequestParam(name="name", required=false) String name) {
        UserResponse response = new UserResponse();
        response.data = userService.getUserInfo(name);
        return response;
    }

    /**
     * @todo: Need to move this code to HTTPInterceptor for
     * getting handled for all response from controllers
     */
    public static class UserResponse extends ApiResponse {
        public UserInfo data;
    }

}