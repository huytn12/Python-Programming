/**
 * User pojo for getting user related details
 * as part of response body.
 */
package com.apple.testapp.model;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;

@Component
public class ApiResponse {
    //Get congifuration values
    // @Value("${app.version}")
    public String apiVersion = "v1.0.11";
    public String error;
}