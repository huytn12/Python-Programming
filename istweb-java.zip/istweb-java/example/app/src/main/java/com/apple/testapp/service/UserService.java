package com.apple.testapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.apple.testapp.dao.UserDao;
import com.apple.testapp.model.UserInfo;
import com.apple.testapp.pojo.User;

@Service("userService")
public class UserService {
	
	@Autowired
	private UserDao userDao;
	
	public UserInfo getUserInfo(String name)  {
		UserInfo userinfo = new UserInfo();
		userinfo.userDetails = userDao.findUserByName(name);
		return userinfo;
	}
}